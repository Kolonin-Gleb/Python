# При запуске данного кода через cmd и передаче 3 аргументов код сработает
import sys

for argument in sys.argv:
    print(f"Аргумент - " str({argv[argument]}))


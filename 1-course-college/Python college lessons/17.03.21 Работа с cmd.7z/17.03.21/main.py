# import os

# print("Your os name is: " + os.name)
# print("Current working directory is " + os.getcwd())

# print("Let's change cwd :-)")
# os.chdir("C:/Users/User/OneDrive/Desktop/17.03.21/txt files") #You have to use / not \, because of escape sequences

# print("Let's create file here :-)")

# with open('test.txt', 'w') as f:
#     f.write("Gleb")

# print("Let's check wheter our file exist")
# print(os.path.exists("test.txt"))

# print("Let's check wheter there is a folder with name \"additional txt files\" ")
# print(os.path.exists("additional txt files"))

# print("Let's check what this directory contains: ")
# print(os.listdir())

###############################################################

# Нужно вывести в консоль название файлов содержащихся в папке
# Если в папке есть директория, то не выводить её название

# import os

# os.chdir("C:/Users/User/OneDrive/Desktop/17.03.21/txt files")

# print("Let's check what files this directory contains: ")

# for obj in os.listdir():
#     if os.path.isfile(obj):
#         print(obj)


# # При запуске данного кода через cmd и передаче 3 аргументов код сработает
# import sys

# print(f"Название файла  - {sys.argv[0]}")
# print(f"Первый аргумент - {sys.argv[1]}")
# print(f"Второй аргумент - {sys.argv[2]}")




# #Выцепить число из строки

# s = "Строка 20"
# numINString = ''

# for i in range(len(s)):
#     if s[i].isdigit():
#         numINString += s[i]
#     else:
#         continue

# numINString = int(numINString)

# print(numINString)


# n = int(input("Введите число = длине и ширине массива"))

# for i in range(n):

# for i in range(n):
#     array[i][n - i - 1] = 1
# for i in range(n):
#     for j in range(n - i, n):
#         array[i][j] = 2
# for row in array:
#     for elem in row:
#         print(elem, end=' ')
#     print()


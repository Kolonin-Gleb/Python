# CSV - comma separated values

# import csv

# data = [
#     ["Tom", 20, "New York"],
#     ["Gleb", 18, "Moscow"],
#     ["John", 18, "Chicago"]
# ]

# with open("test.csv", 'w', newline='') as f:
#     writer = csv.writer(f)
#     writer.writerows(data)


# with open("test.csv", 'r', newline='') as f:
#     reader = csv.reader(f)
#     for row in reader:
#         print(row)
        
# with open("test.csv", 'w', newline='') as f:
#     writer = csv.writer(f, delimiter='|')
#     writer.writerows(data)


# Practise

# Вывести первые 20 строк в консоль из файла

# import csv

# with open("heart_failure_clinical_records_dataset.csv", 'r', newline='') as f:
#     reader = csv.reader(f)
#     rowNum = 0

#     for row in reader:
#         print(row)
#         rowNum +=1
#         if rowNum == 20:
#             break


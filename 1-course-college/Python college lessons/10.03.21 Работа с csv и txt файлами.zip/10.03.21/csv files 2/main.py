import csv

FILENAME = 'heart_failure_clinical_records_dataset.csv'

fileTXT = open('file.txt', 'w')

with open(FILENAME, "r", newline="") as file:
    reader = csv.DictReader(file)
    for row in reader:
        fileTXT.write("age = " +  row["age"] + " anaemia = " + row["anaemia"] + " creatinine_phosphokinase = " + row["creatinine_phosphokinase"] + " diabetes = " + row["diabetes"] + " ejection_fraction = " + row["ejection_fraction"] + " high_blood_pressure = " + row["high_blood_pressure"] + " platelets = " + row["platelets"] + " serum_creatinine = " + row["serum_creatinine"] + " serum_sodium = " + row["serum_sodium"] + " sex = " + row["sex"] + " smoking = " + row["smoking"] + " DEATH_EVENT = " + row["DEATH_EVENT"])

fileTXT.close()

